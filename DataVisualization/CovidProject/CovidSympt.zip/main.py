import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np

df = pd.read_csv("data2.csv")
print(df.dtypes)
print(df.head)
#df['Cases'].astype(str).astype(int)
df['Cases'] = df['Cases'].str.replace(',', '').astype(int)
df['Deaths'] = df['Deaths'].str.replace(',', '').astype(int)
df=df.sort_values('Deaths')
print(df.head)
sns.set_theme(style="ticks",rc={"axes.facecolor": ".92",'figure.facecolor':'gainsboro','axes.edgecolor':".1"})
#ax = sns.scatterplot(x="Name", y=df['Deaths']/df['Cases'], data=df, s=df["Deaths"],hue=df['Deaths']/df['Cases'],legend=True)
ax = sns.scatterplot(x="Name", y=df['Deaths'], data=df, s=df["Deaths"]/2,hue=(df['Deaths']/df['Cases']),legend="full",alpha = 0.8,palette=sns.color_palette(palette="Reds",as_cmap = True),linewidth=1,edgecolor='black',facecolor='black')
#sns.set(rc={'axes.facecolor':'cornflowerblue', 'figure.facecolor':'cornflowerblue'})
maxY=max(df['Deaths'])*2
ax.set(ylim=(-10000, maxY),xlim=(-1,9))
ax.legend(prop={'size': 20},frameon=True,loc = 'upper left')
ax.set_title("Death Count and Mortality Rate",fontsize = 22,weight='semibold')
legend = ax.get_legend()
legend.set_title("Legend")
frame = legend.get_frame()
frame.set_facecolor('lightsteelblue')
for t, l in zip(legend.texts,( "{}- Deaths: {}  Mortality Rate:<0.1 %".format(df['Name'][4],df['Deaths'][4],round((df['Deaths'][4]/df['Cases'][4])*100)),
                              "{}- Deaths: {}  Mortality Rate:<0.1 %".format(df['Name'][5],df['Deaths'][5],round((df['Deaths'][5]/df['Cases'][5])*100)),
                              "{}- Deaths: {}  Mortality Rate:<0.1 %".format(df['Name'][1],df['Deaths'][1],round((df['Deaths'][1]/df['Cases'][1])*100)),
                              "{}- Deaths: {}  Mortality Rate:{} %".format(df['Name'][0],df['Deaths'][0],round((df['Deaths'][0]/df['Cases'][0])*100)),
                              "{}- Deaths: {}  Mortality Rate:{} %".format(df['Name'][3],df['Deaths'][3],round((df['Deaths'][3]/df['Cases'][3])*100)),
                              "{}- Deaths: {}  Mortality Rate:{} %".format(df['Name'][2],df['Deaths'][2],round((df['Deaths'][2]/df['Cases'][2])*100)),
                              "{}- Deaths: {}  Mortality Rate:{} %".format(df['Name'][6],df['Deaths'][6],round((df['Deaths'][6]/df['Cases'][6])*100)),
                              "{}- Deaths: {}  Mortality Rate:{} %".format(df['Name'][7],df['Deaths'][7],round((df['Deaths'][7]/df['Cases'][7])*100)))):
    t.set_text(l)
ax.text(df.Name[0], df.Deaths[0], df.Name[0], horizontalalignment='center', size='large', color='black', weight='semibold')
ax.text(df.Name[1], df.Deaths[1], df.Name[1], horizontalalignment='center', size='medium', color='black', weight='semibold')
ax.text(df.Name[3], df.Deaths[3], df.Name[3], horizontalalignment='center', size='medium', color='black', weight='semibold')
ax.set_xticklabels(df['Name'], fontsize = 14,weight='semibold')
ax.set_yticklabels(df['Deaths'], fontsize = 14,weight='semibold')
#plt.show()
plt.close()








df = pd.read_csv("data1.csv")
print(df.dtypes)
print(df.head)
#df['Cases'].astype(str).astype(int)
df['Cases'] = df['Cases'].str.replace(',', '').astype(int)
df['Deaths'] = df['Deaths'].str.replace(',', '').astype(int)
df=df.sort_values('Cases')
print(df.head)
sns.set_theme(style="ticks",rc={"axes.facecolor": ".92",'figure.facecolor':'gainsboro','axes.edgecolor':".1"})
#ax = sns.scatterplot(x="Name", y=df['Deaths']/df['Cases'], data=df, s=df["Deaths"],hue=df['Deaths']/df['Cases'],legend=True)
ax = sns.scatterplot(x="Name", y=df['Cases'], data=df, s=df["Cases"]/512,hue=(df['Deaths']/df['Cases']),legend="full",alpha = 0.8,palette=sns.color_palette(palette="flare",as_cmap = True),linewidth=1,edgecolor='black',facecolor='black')
ax = sns.scatterplot(x="Name", y=df['Cases'], data=df, s=df["Deaths"]/512,hue=(df['Deaths']/df['Cases']),legend=False,alpha = 0.95,palette=sns.color_palette(palette="mako",as_cmap = True),linewidth=1,edgecolor='black',facecolor='black')
#sns.set(rc={'axes.facecolor':'cornflowerblue', 'figure.facecolor':'cornflowerblue'})
maxY=max(df['Cases'])*2
ax.set(ylim=(-2000000, maxY),xlim=(-1,13))
ax.legend(prop={'size': 20},frameon=True,loc = 'upper left')
ax.set_title("Case Count And Death Count",fontsize = 22,weight='semibold')
legend = ax.get_legend()
legend.set_title("Legend")
frame = legend.get_frame()
frame.set_facecolor('lightsteelblue')
for t, l in zip(legend.texts,( "{}- Cases: {}  Mortality Rate:<0.1 %".format(df['Name'][4],df['Cases'][4],round((df['Deaths'][4]/df['Cases'][4])*100)),
                              "{}- Cases: {}  Mortality Rate:<0.1 %".format(df['Name'][5],df['Cases'][5],round((df['Deaths'][5]/df['Cases'][5])*100)),
                              "{}- Cases: {}  Mortality Rate:<0.1 % %".format(df['Name'][7],df['Cases'][7],round((df['Deaths'][7]/df['Cases'][7])*100)),
                               "{}- Cases: {}  Mortality Rate:<0.1 % %".format(df['Name'][8], df['Cases'][8], round((df['Deaths'][8] / df['Cases'][8]) * 100)),
                               "{}- Cases: {}  Mortality Rate:<0.1 % %".format(df['Name'][9], df['Cases'][9], round((df['Deaths'][9] / df['Cases'][9]) * 100)),
                              "{}- Cases: {}  Mortality Rate:<0.1 %".format(df['Name'][1],df['Cases'][1],round((df['Deaths'][1]/df['Cases'][1])*100)),
                              "{}- Cases: {}  Mortality Rate:{} %".format(df['Name'][0],df['Cases'][0],round((df['Deaths'][0]/df['Cases'][0])*100)),
                              "{}- Cases: {}  Mortality Rate:{} %".format(df['Name'][3],df['Cases'][3],round((df['Deaths'][3]/df['Cases'][3])*100)),
                              "{}- Cases: {}  Mortality Rate:{} %".format(df['Name'][2],df['Cases'][2],round((df['Deaths'][2]/df['Cases'][2])*100)),
                              "{}- Cases: {}  Mortality Rate:{} %".format(df['Name'][6],df['Cases'][6],round((df['Deaths'][6]/df['Cases'][6])*100)),
                               "{}- Cases: {}  Mortality Rate:{} %".format(df['Name'][10], df['Cases'][10], round((df['Deaths'][10] / df['Cases'][10]) * 100)),
                               )):
    t.set_text(l)
ax.text(df.Name[1], df.Cases[1]*1.25, df.Name[1], horizontalalignment='center', size='large', color='black', weight='semibold')
ax.text(df.Name[0], df.Cases[0]*1.25, df.Name[0], horizontalalignment='center', size='large', color='black', weight='semibold')
ax.text(df.Name[8], df.Cases[8]*1.25, df.Name[8], horizontalalignment='center', size='large', color='black', weight='semibold')
ax.text(df.Name[5], df.Cases[5]*1.25, df.Name[5], horizontalalignment='center', size='large', color='black', weight='semibold')
ax.set_xticklabels(df['Name'], fontsize = 14,weight='semibold')
ax.set_yticklabels(df['Cases'], fontsize = 14,weight='semibold')

#plt.show()


##
##Symptom Graph #WIP
##

df = pd.read_csv("CovidFluSympt3.csv")
#print((df.Fever.column!=0).sum())
print(df.head())
#df["Count"]=(df.astype(bool).sum(axis=1)-3)
#df['Count'] = df['Count'].astype(int)
#df=df.sort_values('Count')
#df = df.drop(["Cases","Deaths"],axis=1)
print(df)

ax=df.set_index('Name')\
  .reindex(df.set_index('Name').sum().sort_values().index, axis=1)\
  .T.plot(kind='bar', stacked=True,
          color=sns.color_palette(palette="Paired"),
          figsize=(12,6))
#ax=df.set_index("Name").T.plot(kind='bar', stacked=True,color=sns.color_palette(palette="Paired"))
#df.set_index('Count')\
#  .reindex(df.set_index('Count').sum().sort_values().index, axis=1)\
#  .T.plot(kind='bar', stacked=True,
#          colormap=sns.color_palette("GnBu", 10),
 #         figsize=(12,6))
df2 = pd.read_csv("data1.csv")
#ax.set_xticklabels(df2['Name'], fontsize = 14,weight='semibold')
ax.set_title("Covid Symptom Profile",fontsize = 22,weight='semibold')
lab = ax.get_xticklabels()
ax.set_xticklabels(lab,rotation=0,fontsize = 14,weight='semibold')
ax.set(ylabel='Number of Covid Symptoms', xlabel='Disease')

plt.show()











df = pd.read_csv('CovidFluSymptSort0.csv')
print(df.dtypes)
print(df.head)
#df['Cases'].astype(str).astype(int)
#df['Percent'] = df['Percent'].str.replace(',', '').astype(int)
#df=df.sort_index(ascending=False)
df=df.sort_values('Percent')
print(df.head)
sns.set_theme(style="ticks",rc={"axes.facecolor": ".9",'figure.facecolor':'gainsboro','axes.edgecolor':".1"})

ax = sns.barplot(x="Name", y=df["Percent"]*100, hue="Disease", data=df,palette='deep',linewidth=1,edgecolor='black')
ax.legend(prop={'size': 20},frameon=True,loc = 'upper left')
ax.set_title("Symptom Profile Comparison: Covid19 and Influenza",fontsize = 22,weight='semibold')
legend = ax.get_legend()
legend.set_title("Legend")
frame = legend.get_frame()
frame.set_facecolor('lightgrey')
#for i in ax.patches:
    #print(i.get_width())
    #ax.text(0+0.2, df.Percent[0], df.Name[0], horizontalalignment='center', size='large', color='black', weight='semibold')

plt.show()



##
##
df = pd.read_csv("CovidFluSympt.csv")
print(df.dtypes)
print(df.head)
#df['Cases'].astype(str).astype(int)
sns.set_theme(style="ticks",rc={"axes.facecolor": ".92",'figure.facecolor':'gainsboro','axes.edgecolor':".1"})
#ax = sns.scatterplot(x="Name", y=df['Deaths']/df['Cases'], data=df, s=df["Deaths"],hue=df['Deaths']/df['Cases'],legend=True)
ax = sns.scatterplot(x="Disease", y=df['Percent']*100, data=df, s=(df['Percent']+1)**16,hue=(df['Name']),legend="full",alpha = 0.8,palette=sns.color_palette('bright', n_colors=7),linewidth=1,edgecolor='black',facecolor='black')
#sns.set(rc={'axes.facecolor':'cornflowerblue', 'figure.facecolor':'cornflowerblue'})
ax.set(ylim=(0, 150),xlim=(-2,10))
ax.legend(prop={'size': 20},frameon=True,loc = 'upper left')
ax.set_title("Cluster Plot",fontsize = 22,weight='semibold')
legend = ax.get_legend()
legend.set_title("Legend")
frame = legend.get_frame()
frame.set_facecolor('lightsteelblue')
#ax.set_xticklabels(df['Name'], fontsize = 14,weight='semibold')
#ax.set_yticklabels(df['Percent'], fontsize = 14,weight='semibold')
#plt.show



